// Light/dark theme: remembers the choice in this browser, otherwise follows the device setting.
(function () {
  var KEY = 'theme';
  var root = document.documentElement;
  var COLORS = { light: '#f3f0ea', dark: '#181918' };

  function saved() {
    try {
      var t = localStorage.getItem(KEY);
      return t === 'light' || t === 'dark' ? t : null;
    } catch (e) { return null; }
  }
  function systemDark() {
    return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  }
  function current() { return saved() || (systemDark() ? 'dark' : 'light'); }

  // Apply right away (this file loads before the page is drawn, so there is no flash)
  var start = saved();
  if (start) root.setAttribute('data-theme', start);

  var ICON = 'width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
  var SUN = '<svg ' + ICON + '><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
  var MOON = '<svg ' + ICON + '><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';

  function paint() {
    var theme = current();

    if (saved()) {
      var metas = document.querySelectorAll('meta[name="theme-color"]');
      for (var i = 0; i < metas.length; i++) {
        metas[i].removeAttribute('media');
        metas[i].setAttribute('content', COLORS[theme]);
      }
    }

    var btn = document.getElementById('themeToggle');
    if (btn) {
      var label = theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme';
      btn.innerHTML = theme === 'dark' ? SUN : MOON;
      btn.setAttribute('aria-label', label);
      btn.title = label;
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    paint();
    var btn = document.getElementById('themeToggle');
    if (!btn) return;
    btn.addEventListener('click', function () {
      var next = current() === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem(KEY, next); } catch (e) {}
      paint();
    });
  });

  // If nothing is saved, follow the device when it switches
  if (window.matchMedia) {
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var onChange = function () { if (!saved()) paint(); };
    if (mq.addEventListener) mq.addEventListener('change', onChange);
  }
})();
