'use strict';
// Run once with:  node setup.js
// Creates the admin account (password stored hashed) and a random session secret.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const readline = require('readline');

const file = name => path.join(__dirname, name);
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function ask(question, hidden) {
  return new Promise(resolve => {
    if (!hidden) return rl.question(question, resolve);
    process.stdout.write(question);
    const original = rl._writeToOutput;
    rl._writeToOutput = () => {};
    rl.question('', answer => {
      rl._writeToOutput = original;
      process.stdout.write('\n');
      resolve(answer);
    });
  });
}

(async () => {
  console.log('--- Admin setup ---');
  let username;
  while (true) {
    username = (await ask('Admin username (3-20 letters/numbers/_): ')).trim();
    if (/^[A-Za-z0-9_]{3,20}$/.test(username)) break;
    console.log('Not valid, try again.');
  }

  let password;
  while (true) {
    password = await ask('Admin password (at least 12 characters, typing is hidden): ', true);
    if (password.length < 12 || password.length > 100) { console.log('Needs 12-100 characters.'); continue; }
    const again = await ask('Repeat password: ', true);
    if (again === password) break;
    console.log('Passwords did not match, try again.');
  }
  rl.close();

  let users = [];
  try { users = JSON.parse(fs.readFileSync(file('users.json'), 'utf8') || '[]'); } catch { /* new file */ }

  // Remove any older admin, and any normal user that has the same name
  users = users.filter(u => u.role !== 'admin' && u.username.toLowerCase() !== username.toLowerCase());

  const salt = crypto.randomBytes(16).toString('hex');
  users.push({
    username,
    role: 'admin',
    salt,
    hash: crypto.scryptSync(password, salt, 64).toString('hex'),
    createdAt: new Date().toISOString()
  });
  fs.writeFileSync(file('users.json'), JSON.stringify(users, null, 2));

  if (!fs.existsSync(file('.env'))) {
    fs.writeFileSync(file('.env'), `SESSION_SECRET=${crypto.randomBytes(48).toString('hex')}\n`);
    console.log('Created .env with a random session secret.');
  }

  if (!fs.existsSync(file('.gitignore'))) {
    fs.writeFileSync(file('.gitignore'), 'node_modules\n.env\nusers.json\nnotes.json\ndatabase.txt\nlogin-log.txt\n');
  }

  console.log(`Done. Admin "${username}" is ready. Now run: node server.js`);
})();
