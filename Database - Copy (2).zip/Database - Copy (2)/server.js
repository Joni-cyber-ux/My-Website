'use strict';

const express = require('express');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const file = name => path.join(__dirname, name);

// ---------- Secrets come from .env (created by setup.js) ----------
try {
  for (const line of fs.readFileSync(file('.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
  }
} catch { /* no .env yet */ }

if (!process.env.SESSION_SECRET) {
  console.error('Missing .env file. Run "node setup.js" first.');
  process.exit(1);
}

const PORT = Number(process.env.PORT) || 3000;
// 127.0.0.1 = only this computer can reach the site. Set HOST=0.0.0.0 in .env to open it to your network.
const HOST = process.env.HOST || '127.0.0.1';
const IS_PROD = process.env.NODE_ENV === 'production';

const USERS_FILE = file('users.json');
const PEOPLE_FILE = file('database.txt');
const MESSAGES_FILE = file('messages.json');
const READS_FILE = file('reads.json');
const LOG_FILE = file('login-log.txt');
const UPLOAD_DIR = file('uploads');
// Biggest file one person can send (change with MAX_FILE_MB=50 in .env, limit 100)
const MAX_FILE_MB = Math.min(Math.max(Number(process.env.MAX_FILE_MB) || 25, 1), 100);
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const PROFILE_DIR = file('profile-pics');   // profile pictures and banners
fs.mkdirSync(PROFILE_DIR, { recursive: true });

// ---------- Storage helpers (atomic writes so a crash can't corrupt files) ----------
function readJSON(filePath, fallback) {
  try {
    const text = fs.readFileSync(filePath, 'utf8');
    return text.trim() ? JSON.parse(text) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(filePath, data) {
  const tmp = filePath + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, filePath);
}

const readUsers = () => readJSON(USERS_FILE, []).map(u => ({ role: 'user', ...u }));
const findUser = name => readUsers().find(u => u.username.toLowerCase() === String(name).toLowerCase());

// ---------- Passwords ----------
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

// Used when the username doesn't exist, so the response takes the same time either way
const DUMMY_SALT = crypto.randomBytes(16).toString('hex');
const DUMMY_HASH = Buffer.from(hashPassword('dummy-password', DUMMY_SALT), 'hex');

function verifyPassword(password, user) {
  const salt = user ? user.salt : DUMMY_SALT;
  const attempt = Buffer.from(hashPassword(password, salt), 'hex');
  const stored = user ? Buffer.from(user.hash, 'hex') : DUMMY_HASH;
  const match = attempt.length === stored.length && crypto.timingSafeEqual(attempt, stored);
  return Boolean(user) && match;
}

if (!readUsers().some(u => u.role === 'admin')) {
  console.error('No admin account found. Run "node setup.js" first.');
  process.exit(1);
}

// ---------- Login log (cleaned so nobody can inject fake lines) ----------
function logEvent(status, username, ip) {
  const clean = s => String(s).replace(/[^\w.:@-]/g, '_').slice(0, 50);
  const line = `${new Date().toISOString()} | ${status} | user: ${clean(username)} | ip: ${clean(ip)}\n`;
  fs.appendFile(LOG_FILE, line, () => {});
}

// ---------- Rate limiting (in memory) ----------
function makeLimiter(max, windowMs) {
  const hits = new Map();
  return {
    blocked(key) {
      const h = hits.get(key);
      if (!h) return false;
      if (Date.now() - h.start > windowMs) { hits.delete(key); return false; }
      return h.count >= max;
    },
    add(key) {
      const now = Date.now();
      const h = hits.get(key);
      if (!h || now - h.start > windowMs) hits.set(key, { count: 1, start: now });
      else h.count++;
    },
    reset(key) { hits.delete(key); }
  };
}

const loginByUser = makeLimiter(5, 15 * 60 * 1000);   // 5 wrong tries per IP+username
const loginByIp = makeLimiter(20, 15 * 60 * 1000);    // 20 wrong tries per IP
const registerByIp = makeLimiter(5, 60 * 60 * 1000);  // 5 sign-ups per IP per hour
const sendLimiter = makeLimiter(30, 60 * 1000);       // 30 messages per minute per user
const searchLimiter = makeLimiter(60, 60 * 1000);     // 60 searches per minute per user
const passwordByUser = makeLimiter(5, 15 * 60 * 1000); // 5 wrong "current password" tries per user
const uploadLimiter = makeLimiter(10, 60 * 1000);      // 10 files per minute per user
const profileLimiter = makeLimiter(20, 60 * 1000);     // 20 profile edits per minute per user
const profileImgLimiter = makeLimiter(10, 60 * 1000);  // 10 profile pictures per minute per user

// ---------- Admin audit log: who did what ----------
function auditLog(admin, action, target) {
  const clean = x => String(x).replace(/[^\w.:@& -]/g, '_').slice(0, 80);
  const line = `${new Date().toISOString()} | ${clean(admin)} | ${action} | ${clean(target)}\n`;
  fs.appendFile(file('admin-audit.log'), line, () => {});
}

// ---------- One-time login codes (made by an admin, kept in memory, stored hashed) ----------
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const loginCodes = new Map(); // lowercase username -> { hash, expires }
const sha = text => crypto.createHash('sha256').update(text).digest();

function newLoginCode(username) {
  for (const [key, entry] of loginCodes) if (entry.expires < Date.now()) loginCodes.delete(key);
  let raw = '';
  for (let i = 0; i < 10; i++) raw += CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)];
  loginCodes.set(username.toLowerCase(), { hash: sha(raw), expires: Date.now() + 10 * 60 * 1000 });
  return raw.slice(0, 5) + '-' + raw.slice(5);
}

function consumeLoginCode(username, input) {
  const key = username.toLowerCase();
  const entry = loginCodes.get(key);
  if (!entry || entry.expires < Date.now()) return false;
  const cleaned = String(input).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const ok = crypto.timingSafeEqual(sha(cleaned), entry.hash);
  if (ok) loginCodes.delete(key); // works only once
  return ok;
}

const app = express();
app.disable('x-powered-by');
// Behind a tunnel or hosting service? Set TRUST_PROXY=1 in .env so cookies and IP addresses work correctly.
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);

// ---------- Security headers ----------
app.use((req, res, next) => {
  res.locals.nonce = crypto.randomBytes(16).toString('base64');
  res.set({
    'Content-Security-Policy':
      `default-src 'self'; script-src 'self' 'nonce-${res.locals.nonce}'; style-src 'self'; ` +
      `img-src 'self' data:; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'`,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Cache-Control': 'no-store'
  });
  if (IS_PROD) res.set('Strict-Transport-Security', 'max-age=15552000');
  next();
});

app.use(express.json({ limit: '10kb' }));

// ---------- CSRF protection: same-origin + JSON only for anything that changes data ----------
app.use((req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (origin) {
    let ok = false;
    try { ok = new URL(origin).host === req.get('host'); } catch { /* bad origin */ }
    if (!ok) return res.status(403).json({ error: 'Blocked: bad origin' });
  }
  const isUpload = req.method === 'POST' && /^\/api\/(messages\/[^/]+\/file|profile\/(avatar|banner))$/.test(req.path);
  if (!req.is('application/json') && !(isUpload && req.is('application/octet-stream'))) {
    return res.status(415).json({ error: 'JSON only' });
  }
  next();
});

app.use(session({
  name: 'sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,          // JavaScript on the page can't read the cookie
    sameSite: 'strict',      // other websites can't send it
    secure: IS_PROD,         // HTTPS only when NODE_ENV=production
    maxAge: 2 * 60 * 60 * 1000 // auto logout after 2 hours of inactivity
  }
}));

// ---------- Access control ----------
function requireAuth(req, res, next) {
  if (req.session.loggedIn) return next();
  if (req.originalUrl.startsWith('/api')) return res.status(401).json({ error: 'Not logged in' });
  res.redirect('/login');
}

function requireAdmin(req, res, next) {
  if (req.session.loggedIn && req.session.role === 'admin') return next();
  if (!req.session.loggedIn) {
    if (req.originalUrl.startsWith('/api')) return res.status(401).json({ error: 'Not logged in' });
    return res.redirect('/login');
  }
  if (req.originalUrl.startsWith('/api')) return res.status(403).json({ error: 'Admins only' });
  res.redirect('/');
}

// ---------- Pages (HTML files are never served directly, only through these routes) ----------
function sendPage(res, name) {
  fs.readFile(file(name), 'utf8', (err, html) => {
    if (err) return res.status(500).send('Server error');
    res.type('html').send(html.replace(/__NONCE__/g, res.locals.nonce));
  });
}

app.get('/style.css', (req, res) => res.sendFile(file('style.css')));

// Files the browser needs before anyone logs in (app manifest, icons, offline page)
const PUBLIC_FILES = {
  '/manifest.webmanifest': 'application/manifest+json',
  '/sw.js': 'text/javascript',
  '/pwa.js': 'text/javascript',
  '/theme.js': 'text/javascript',
  '/profile-ui.js': 'text/javascript',
  '/offline.html': 'text/html',
  '/icon-192.png': 'image/png',
  '/icon-512.png': 'image/png',
  '/icon-maskable.png': 'image/png',
  '/apple-touch-icon.png': 'image/png'
};
for (const [route, type] of Object.entries(PUBLIC_FILES)) {
  app.get(route, (req, res) => {
    res.type(type);
    if (route === '/sw.js') res.set('Service-Worker-Allowed', '/');
    if (type === 'image/png') res.set('Cache-Control', 'public, max-age=86400');
    res.sendFile(file(route.slice(1)));
  });
}

app.get('/login', (req, res) => {
  if (req.session.loggedIn) return res.redirect('/');
  sendPage(res, 'login.html');
});

app.get('/register', (req, res) => {
  if (req.session.loggedIn) return res.redirect('/');
  sendPage(res, 'register.html');
});

app.get('/', requireAuth, (req, res) => {
  res.redirect(req.session.role === 'admin' ? '/admin' : '/chat');
});

app.get('/chat', requireAuth, (req, res) => sendPage(res, 'chat.html'));
// Admins can't change their password from the site (the server owner can re-run setup.js)
app.get('/password', requireAuth, (req, res) => {
  if (req.session.role === 'admin') return res.redirect('/');
  sendPage(res, 'password.html');
});
app.get('/profile', requireAuth, (req, res) => sendPage(res, 'profile.html'));
app.get('/home', requireAuth, (req, res) => res.redirect('/chat'));
app.get('/admin', requireAdmin, (req, res) => sendPage(res, 'index.html'));
app.get('/admin/chat/:a/:b', requireAdmin, (req, res) => {
  if (!USERNAME_RE.test(req.params.a) || !USERNAME_RE.test(req.params.b)) return res.redirect('/admin');
  sendPage(res, 'adminchat.html');
});

// ---------- Register / login / logout ----------
const USERNAME_RE = /^[A-Za-z0-9_]{3,20}$/;

app.post('/register', (req, res) => {
  const { username, password } = req.body || {};

  if (registerByIp.blocked(req.ip)) {
    return res.status(429).json({ error: 'Too many sign-ups from your connection. Try again later.' });
  }
  registerByIp.add(req.ip);

  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: 'Invalid data' });
  }
  if (!USERNAME_RE.test(username)) {
    return res.status(400).json({ error: 'Username: 3-20 characters, letters, numbers and _ only' });
  }
  if (password.length < 8 || password.length > 100) {
    return res.status(400).json({ error: 'Password must be 8-100 characters' });
  }
  if (password.toLowerCase() === username.toLowerCase()) {
    return res.status(400).json({ error: 'Password can\'t be the same as the username' });
  }
  if (findUser(username)) {
    return res.status(409).json({ error: 'Username already taken' });
  }

  const salt = crypto.randomBytes(16).toString('hex');
  const users = readJSON(USERS_FILE, []);
  users.push({
    username,
    role: 'user',
    salt,
    hash: hashPassword(password, salt),
    createdAt: new Date().toISOString()
  });
  writeJSON(USERS_FILE, users);
  res.json({ ok: true });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string' ||
      username.length > 50 || password.length > 200) {
    return res.status(400).json({ error: 'Invalid data' });
  }

  const ip = req.ip;
  const userKey = ip + '|' + username.toLowerCase();

  if (loginByIp.blocked(ip) || loginByUser.blocked(userKey)) {
    logEvent('BLOCKED', username, ip);
    return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' });
  }

  const user = findUser(username);
  let ok = verifyPassword(password, user);
  let viaCode = false;
  if (!ok && user && user.role !== 'admin' && consumeLoginCode(user.username, password)) {
    ok = true;
    viaCode = true;
  }
  if (ok) {
    loginByUser.reset(userKey);
    // New session id on login stops "session fixation" attacks
    return req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: 'Server error' });
      req.session.loggedIn = true;
      req.session.user = user.username;
      req.session.role = user.role;
      logEvent(viaCode ? 'SUCCESS-CODE' : 'SUCCESS', user.username, ip);
      res.json({ ok: true });
    });
  }

  loginByIp.add(ip);
  loginByUser.add(userKey);
  logEvent('FAILED', username, ip);
  res.status(401).json({ error: 'Wrong username or password' });
});

app.post('/logout', (req, res) => {
  // Close this session's live connections right away
  const set = sseClients.get(req.session.user);
  if (set) for (const c of [...set]) if (c.sid === req.sessionID) c.res.end();

  req.session.destroy(() => {
    res.clearCookie('sid');
    res.json({ ok: true });
  });
});

// =====================================================================
//  Messaging
// =====================================================================

// messages: [{ seq, id, from, to, text, ts }], oldest first
let messages = readJSON(MESSAGES_FILE, []);
// reads: { "reader|other": lastSeqRead }  (flat keys on purpose)
let reads = readJSON(READS_FILE, {});
let nextSeq = messages.reduce((max, m) => Math.max(max, m.seq), 0) + 1;

function flushData() {
  writeJSON(MESSAGES_FILE, messages);
  writeJSON(READS_FILE, reads);
}

let saveTimer = null;
function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => { saveTimer = null; flushData(); }, 300);
}

process.on('SIGINT', () => { flushData(); process.exit(0); });
process.on('SIGTERM', () => { flushData(); process.exit(0); });

const readKey = (reader, other) => reader + '|' + other;
const readSeq = (reader, other) => reads[readKey(reader, other)] || 0;
const between = (a, b) => m => (m.from === a && m.to === b) || (m.from === b && m.to === a);
const publicMsg = m => ({ id: m.id, seq: m.seq, from: m.from, to: m.to, text: m.text, ts: m.ts, file: m.file });

// ---------- Live updates (Server-Sent Events) ----------
const sseClients = new Map(); // username -> Set<{ res, sid }>
const isOnline = name => (sseClients.get(name) || new Set()).size > 0;

function pushTo(username, event) {
  const set = sseClients.get(username);
  if (!set) return;
  const data = `data: ${JSON.stringify(event)}\n\n`;
  for (const c of set) c.res.write(data);
}

function pushAll(event) {
  for (const name of sseClients.keys()) pushTo(name, event);
}

app.use('/api', requireAuth);

app.get('/api/events', (req, res) => {
  const me = req.session.user;
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-store',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no'
  });
  res.flushHeaders();
  res.write('retry: 3000\n');
  res.write(': ' + ' '.repeat(2048) + '\n\n');   // padding pushes the first bytes through proxies that buffer
  res.write('data: {"type":"hello"}\n\n');

  let set = sseClients.get(me);
  const wasOnline = Boolean(set && set.size > 0);
  if (!set) { set = new Set(); sseClients.set(me, set); }
  while (set.size >= 5) { // max 5 tabs per user
    const oldest = set.values().next().value;
    set.delete(oldest);
    oldest.res.end();
  }

  const client = { res, sid: req.sessionID };
  set.add(client);
  if (!wasOnline) pushAll({ type: 'presence', user: me, online: true });

  // Keep the connection alive, and close it if the login expired
  const timer = setInterval(() => {
    req.sessionStore.get(client.sid, (err, sess) => {
      if (err || !sess || !sess.loggedIn) return res.end();
      res.write('data: {"type":"ping"}\n\n');
    });
  }, 20000);

  req.on('close', () => {
    clearInterval(timer);
    set.delete(client);
    if (set.size === 0) {
      sseClients.delete(me);
      pushAll({ type: 'presence', user: me, online: false });
    }
  });
});

app.get('/api/me', (req, res) => {
  res.json({
    username: req.session.user,
    role: req.session.role,
    maxFileMB: MAX_FILE_MB,
    profile: publicProfile(findUser(req.session.user) || { username: req.session.user, role: req.session.role })
  });
});

// Change my own password (needs the current one). Works for users and admins.
app.post('/api/password', (req, res) => {
  const me = req.session.user;
  if (req.session.role === 'admin') {
    return res.status(403).json({ error: 'Admin accounts can\'t change their password here.' });
  }
  const { currentPassword, newPassword } = req.body || {};

  if (typeof currentPassword !== 'string' || typeof newPassword !== 'string' || currentPassword.length > 200) {
    return res.status(400).json({ error: 'Invalid data' });
  }
  if (passwordByUser.blocked(me)) {
    logEvent('BLOCKED-PASSWORD-CHANGE', me, req.ip);
    return res.status(429).json({ error: 'Too many wrong attempts. Try again in 15 minutes.' });
  }

  const users = readJSON(USERS_FILE, []);
  const index = users.findIndex(u => u.username === me);
  if (index === -1) return res.status(404).json({ error: 'Account not found' });

  if (!verifyPassword(currentPassword, users[index])) {
    passwordByUser.add(me);
    logEvent('FAILED-PASSWORD-CHANGE', me, req.ip);
    return res.status(403).json({ error: 'Current password is wrong' });
  }

  if (newPassword.length < 8 || newPassword.length > 100) {
    return res.status(400).json({ error: 'New password must be 8-100 characters' });
  }
  if (newPassword.toLowerCase() === me.toLowerCase()) {
    return res.status(400).json({ error: 'Password can\'t be the same as the username' });
  }
  if (newPassword === currentPassword) {
    return res.status(400).json({ error: 'New password must be different from the current one' });
  }

  const salt = crypto.randomBytes(16).toString('hex');
  users[index].salt = salt;
  users[index].hash = hashPassword(newPassword, salt);
  users[index].passwordChangedAt = new Date().toISOString();
  writeJSON(USERS_FILE, users);

  passwordByUser.reset(me);
  loginCodes.delete(me.toLowerCase()); // an old one-time code must not outlive the change
  logEvent('PASSWORD-CHANGED', me, req.ip);

  // Log this account out everywhere else; this device stays logged in
  const keepSid = req.sessionID;
  const finish = () => {
    const live = sseClients.get(me);
    if (live) for (const c of [...live]) if (c.sid !== keepSid) c.res.end();
    res.json({ ok: true });
  };
  const store = req.sessionStore;
  if (typeof store.all !== 'function') return finish();
  store.all((err, all) => {
    if (!err && all && !Array.isArray(all)) {
      for (const [sid, sess] of Object.entries(all)) {
        if (sid !== keepSid && sess && sess.user === me) store.destroy(sid, () => {});
      }
    }
    finish();
  });
});

// =====================================================================
//  Profiles: nickname, about me, colour, profile picture and banner
// =====================================================================
const AVATAR_MB = 2;
const BANNER_MB = 5;
const IMAGE_EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' };
const EXT_TYPE = { png: 'image/png', jpg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp' };
const MEDIA_RE = /^[a-f0-9]{32}\.(png|jpg|gif|webp)$/;
// Invisible and direction-changing characters can be used to fake names, so they are removed
const HIDDEN = /[\u0000-\u001f\u007f-\u009f\u00ad\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/g;
const HIDDEN_KEEP_NEWLINE = /[\u0000-\u0009\u000b-\u001f\u007f-\u009f\u00ad\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/g;
const lengthOf = s => Array.from(s).length;

// What everyone is allowed to see about a person
function publicProfile(u) {
  const p = u.profile || {};
  return {
    username: u.username,
    role: u.role || 'user',
    nickname: p.nickname || '',
    bio: p.bio || '',
    color: p.color || '',
    avatar: p.avatar || '',
    banner: p.banner || '',
    since: u.createdAt || null
  };
}

const announceProfile = u => pushAll({ type: 'profile', profile: publicProfile({ role: 'user', ...u }) });
const dropProfileImage = name => { if (MEDIA_RE.test(name || '')) fs.unlink(path.join(PROFILE_DIR, name), () => {}); };

app.get('/api/profile/:username', (req, res) => {
  const user = findUser(req.params.username);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(publicProfile(user));
});

app.post('/api/profile', (req, res) => {
  const me = req.session.user;
  if (profileLimiter.blocked(me)) return res.status(429).json({ error: 'Slow down a little.' });
  profileLimiter.add(me);

  const { nickname = '', bio = '', color = '' } = req.body || {};
  if ([nickname, bio, color].some(v => typeof v !== 'string')) return res.status(400).json({ error: 'Invalid data' });

  const nick = nickname.replace(HIDDEN, '').replace(/\s+/g, ' ').trim();
  const about = bio.replace(/\r\n/g, '\n').replace(HIDDEN_KEEP_NEWLINE, '').replace(/\n{3,}/g, '\n\n').trim();
  if (lengthOf(nick) > 32) return res.status(400).json({ error: 'Nickname can be at most 32 characters' });
  if (lengthOf(about) > 190) return res.status(400).json({ error: 'About me can be at most 190 characters' });
  if (color && !/^#[0-9a-fA-F]{6}$/.test(color)) return res.status(400).json({ error: 'Colour must look like #2b7a5b' });

  const users = readJSON(USERS_FILE, []);
  const i = users.findIndex(u => u.username === me);
  if (i === -1) return res.status(404).json({ error: 'Account not found' });
  // A nickname can't be someone else's username, so nobody can pretend to be another account
  if (nick && users.some(u => u.username !== me && u.username.toLowerCase() === nick.toLowerCase())) {
    return res.status(400).json({ error: 'That name belongs to another account' });
  }

  users[i].profile = { ...(users[i].profile || {}), nickname: nick, bio: about, color: color.toLowerCase() };
  writeJSON(USERS_FILE, users);
  announceProfile(users[i]);
  res.json(publicProfile({ role: 'user', ...users[i] }));
});

// Profile picture and banner: the picture is sent as the raw request body
function profileImage(kind, maxMB) {
  app.post('/api/profile/' + kind,
    express.raw({ type: 'application/octet-stream', limit: maxMB * 1024 * 1024 }),
    async (req, res) => {
      const me = req.session.user;
      if (!Buffer.isBuffer(req.body) || req.body.length === 0) return res.status(400).json({ error: 'No picture received' });
      if (profileImgLimiter.blocked(me)) return res.status(429).json({ error: 'Slow down a little.' });
      profileImgLimiter.add(me);

      const type = sniffImage(req.body);
      if (!type) return res.status(400).json({ error: 'Pictures only (png, jpg, gif or webp)' });

      const name = crypto.randomBytes(16).toString('hex') + '.' + IMAGE_EXT[type];
      try {
        await fs.promises.writeFile(path.join(PROFILE_DIR, name), req.body, { mode: 0o600 });
      } catch (e) {
        console.error(e);
        return res.status(500).json({ error: 'Could not save the picture' });
      }

      const users = readJSON(USERS_FILE, []);
      const i = users.findIndex(u => u.username === me);
      if (i === -1) { dropProfileImage(name); return res.status(404).json({ error: 'Account not found' }); }
      const old = (users[i].profile || {})[kind];
      users[i].profile = { ...(users[i].profile || {}), [kind]: name };
      writeJSON(USERS_FILE, users);
      dropProfileImage(old);
      announceProfile(users[i]);
      res.json(publicProfile({ role: 'user', ...users[i] }));
    });

  app.delete('/api/profile/' + kind, (req, res) => {
    const me = req.session.user;
    const users = readJSON(USERS_FILE, []);
    const i = users.findIndex(u => u.username === me);
    if (i === -1) return res.status(404).json({ error: 'Account not found' });
    const old = (users[i].profile || {})[kind];
    users[i].profile = { ...(users[i].profile || {}), [kind]: '' };
    writeJSON(USERS_FILE, users);
    dropProfileImage(old);
    announceProfile(users[i]);
    res.json(publicProfile({ role: 'user', ...users[i] }));
  });
}
profileImage('avatar', AVATAR_MB);
profileImage('banner', BANNER_MB);

// Show a profile picture or banner (any logged-in person can see these)
app.get('/media/:name', requireAuth, (req, res) => {
  const m = MEDIA_RE.exec(req.params.name);
  if (!m) return res.status(404).type('text').send('Not found');
  res.set({
    'Content-Type': EXT_TYPE[m[1]],
    'Content-Security-Policy': "default-src 'none'; sandbox",
    'Cache-Control': 'private, max-age=604800, immutable'
  });
  res.sendFile(path.join(PROFILE_DIR, req.params.name), { cacheControl: false }, err => {
    if (err && !res.headersSent) res.status(404).type('text').send('Not found');
  });
});

// Search users to start a chat with
app.get('/api/users/search', (req, res) => {
  const me = req.session.user;
  const q = String(req.query.q || '').trim().toLowerCase();
  if (!q || q.length > 20) return res.json([]);
  if (searchLimiter.blocked(me)) return res.status(429).json({ error: 'Slow down a little.' });
  searchLimiter.add(me);
  res.json(
    readUsers()
      .filter(u => u.username !== me && (u.username.toLowerCase().includes(q) ||
        ((u.profile && u.profile.nickname) || '').toLowerCase().includes(q)))
      .slice(0, 10)
      .map(u => ({ username: u.username, online: isOnline(u.username), profile: publicProfile(u) }))
  );
});

// My conversations, newest first
app.get('/api/chats', (req, res) => {
  const me = req.session.user;
  const byPeer = new Map();
  const byName = new Map(readUsers().map(u => [u.username, u]));
  for (const m of messages) {
    if (m.from !== me && m.to !== me) continue;
    const peer = m.from === me ? m.to : m.from;
    let chat = byPeer.get(peer);
    if (!chat) {
      const u = byName.get(peer);
      chat = { peer, online: isOnline(peer), unread: 0, last: null, profile: publicProfile(u || { username: peer }) };
      byPeer.set(peer, chat);
    }
    chat.last = publicMsg(m);
    if (m.to === me && m.seq > readSeq(me, peer)) chat.unread++;
  }
  res.json([...byPeer.values()].sort((a, b) => b.last.seq - a.last.seq));
});

// Messages of one conversation (newest 50, or older ones with ?before=<seq>)
app.get('/api/messages/:peer', (req, res) => {
  const me = req.session.user;
  const peer = findUser(req.params.peer);
  if (!peer || peer.username === me) return res.status(404).json({ error: 'User not found' });

  const before = Number(req.query.before) || Infinity;
  const all = messages.filter(between(me, peer.username)).filter(m => m.seq < before);
  const page = all.slice(-50);
  res.json({
    peer: peer.username,
    profile: publicProfile(peer),
    online: isOnline(peer.username),
    peerRead: readSeq(peer.username, me),
    hasMore: all.length > page.length,
    messages: page.map(publicMsg)
  });
});

app.post('/api/messages/:peer', (req, res) => {
  const me = req.session.user;
  const peer = findUser(req.params.peer);
  if (!peer || peer.username === me) return res.status(404).json({ error: 'User not found' });

  if (sendLimiter.blocked(me)) {
    return res.status(429).json({ error: 'You are sending too fast. Wait a moment.' });
  }
  sendLimiter.add(me);

  const text = typeof req.body.text === 'string'
    ? req.body.text.replace(/\r\n/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim()
    : '';
  if (!text || text.length > 2000) {
    return res.status(400).json({ error: 'Message must be 1-2000 characters.' });
  }

  const m = { seq: nextSeq++, id: crypto.randomUUID(), from: me, to: peer.username, text, ts: Date.now() };
  messages.push(m);
  scheduleSave();

  const event = { type: 'message', message: publicMsg(m) };
  pushTo(me, event);
  pushTo(peer.username, event);
  res.json(publicMsg(m));
});

// ---------- Sending files and pictures ----------
const cleanText = t => typeof t === 'string'
  ? t.replace(/\r\n/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim()
  : '';

// Look at the first bytes to see if it really is a picture the browser can show
function sniffImage(buf) {
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length >= 6 && /^GIF8[79]a$/.test(buf.toString('latin1', 0, 6))) return 'image/gif';
  if (buf.length >= 12 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return 'image/webp';
  return null;
}

function cleanFileName(name) {
  let n = String(name || '').replace(/[\u0000-\u001f\u007f\\/:*?"<>|]/g, '_').replace(/^\.+/, '').trim();
  if (n.length > 100) {
    const ext = path.extname(n).slice(0, 10);
    n = n.slice(0, 100 - ext.length) + ext;
  }
  return n || 'file';
}

// The file itself is sent as the raw request body: POST /api/messages/<person>/file?name=<file name>&text=<optional caption>
app.post('/api/messages/:peer/file',
  express.raw({ type: 'application/octet-stream', limit: MAX_FILE_MB * 1024 * 1024 }),
  async (req, res) => {
    const me = req.session.user;
    const peer = findUser(req.params.peer);
    if (!peer || peer.username === me) return res.status(404).json({ error: 'User not found' });
    if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
      return res.status(400).json({ error: 'No file received' });
    }
    if (uploadLimiter.blocked(me)) {
      return res.status(429).json({ error: 'You are sending files too fast. Wait a moment.' });
    }
    uploadLimiter.add(me);

    const text = cleanText(req.query.text);
    if (text.length > 2000) return res.status(400).json({ error: 'Caption must be at most 2000 characters.' });

    const fileId = crypto.randomBytes(16).toString('hex');
    try {
      await fs.promises.writeFile(path.join(UPLOAD_DIR, fileId), req.body, { mode: 0o600 });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ error: 'Could not save the file' });
    }

    const m = {
      seq: nextSeq++, id: crypto.randomUUID(), from: me, to: peer.username, text, ts: Date.now(),
      file: { id: fileId, name: cleanFileName(req.query.name), size: req.body.length, image: sniffImage(req.body) }
    };
    messages.push(m);
    scheduleSave();

    const event = { type: 'message', message: publicMsg(m) };
    pushTo(me, event);
    pushTo(peer.username, event);
    res.json(publicMsg(m));
  });

// Download or show a file. Only the two people in that chat (and admins) can open it.
app.get('/files/:id', requireAuth, (req, res) => {
  const me = req.session.user;
  const m = /^[a-f0-9]{32}$/.test(req.params.id) && messages.find(x => x.file && x.file.id === req.params.id);
  const mine = m && (m.from === me || m.to === me);
  if (!m || (!mine && req.session.role !== 'admin')) return res.status(404).type('text').send('Not found');
  if (!mine) auditLog(me, 'VIEWED_FILE', m.from + ' & ' + m.to);

  const f = m.file;
  const asciiName = f.name.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
  const utf8Name = encodeURIComponent(f.name).replace(/['()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
  res.set({
    // Pictures show inside the chat; everything else is always downloaded, never opened by the browser
    'Content-Type': f.image || 'application/octet-stream',
    'Content-Disposition': (f.image ? 'inline' : 'attachment') + '; filename="' + asciiName + "\"; filename*=UTF-8''" + utf8Name,
    'Content-Security-Policy': "default-src 'none'; sandbox",
    'Cache-Control': 'private, max-age=86400, immutable'
  });
  res.sendFile(path.join(UPLOAD_DIR, f.id), { cacheControl: false }, err => {
    if (err && !res.headersSent) res.status(404).type('text').send('File is gone');
  });
});

// Delete one of my own messages (for both people)
app.delete('/api/messages/:id', (req, res) => {
  const me = req.session.user;
  const index = messages.findIndex(m => m.id === req.params.id && m.from === me);
  if (index === -1) return res.status(404).json({ error: 'Message not found' });

  const [removed] = messages.splice(index, 1);
  scheduleSave();
  if (removed.file) fs.unlink(path.join(UPLOAD_DIR, removed.file.id), () => {});

  const event = { type: 'delete', id: removed.id };
  pushTo(removed.from, { ...event, peer: removed.to });
  pushTo(removed.to, { ...event, peer: removed.from });
  res.json({ ok: true });
});

// Mark everything from this person as read
app.post('/api/chats/:peer/read', (req, res) => {
  const me = req.session.user;
  const peer = findUser(req.params.peer);
  if (!peer) return res.status(404).json({ error: 'User not found' });

  let last = 0;
  for (const m of messages) {
    if (m.from === peer.username && m.to === me && m.seq > last) last = m.seq;
  }
  if (last > readSeq(me, peer.username)) {
    reads[readKey(me, peer.username)] = last;
    scheduleSave();
    pushTo(peer.username, { type: 'read', by: me, upTo: last }); // their "seen" ticks
    pushTo(me, { type: 'seen', peer: peer.username });           // my other tabs
  }
  res.json({ ok: true });
});

// ---------- Admin only: users and people (message contents stay private) ----------
app.get('/api/users', requireAdmin, (req, res) => {
  const sent = new Map();
  for (const m of messages) sent.set(m.from, (sent.get(m.from) || 0) + 1);
  res.json(readUsers().map(u => ({
    username: u.username,
    role: u.role,
    sent: sent.get(u.username) || 0,
    online: isOnline(u.username),
    profile: publicProfile(u)
  })));
});

// One-time login code for a normal user (shown once to the admin)
app.post('/api/admin/users/:username/login-code', requireAdmin, (req, res) => {
  const user = findUser(req.params.username);
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (user.role === 'admin') return res.status(400).json({ error: 'Admin accounts do not use codes.' });
  const code = newLoginCode(user.username);
  auditLog(req.session.user, 'CREATED_LOGIN_CODE', user.username);
  res.json({ code, minutes: 10 });
});

// Every conversation on the site
app.get('/api/admin/chats', requireAdmin, (req, res) => {
  const pairs = new Map();
  for (const m of messages) {
    const [a, b] = [m.from, m.to].sort();
    const key = a + '|' + b;
    let pair = pairs.get(key);
    if (!pair) { pair = { a, b, count: 0, last: null }; pairs.set(key, pair); }
    pair.count++;
    pair.last = publicMsg(m);
  }
  res.json([...pairs.values()].sort((x, y) => y.last.seq - x.last.seq));
});

// All messages between two people (newest 100, or older ones with ?before=<seq>)
app.get('/api/admin/chats/:a/:b', requireAdmin, (req, res) => {
  // Accounts may have been removed since the chat happened, so fall back to the name in the link
  const nameA = (findUser(req.params.a) || { username: req.params.a }).username;
  const nameB = (findUser(req.params.b) || { username: req.params.b }).username;
  if (!USERNAME_RE.test(nameA) || !USERNAME_RE.test(nameB) || nameA === nameB) {
    return res.status(404).json({ error: 'Conversation not found' });
  }

  const before = Number(req.query.before) || Infinity;
  const all = messages.filter(between(nameA, nameB)).filter(m => m.seq < before);
  if (all.length === 0 && before === Infinity && (!findUser(nameA) || !findUser(nameB))) {
    return res.status(404).json({ error: 'No such conversation, and one of the accounts does not exist.' });
  }
  const page = all.slice(-100);
  if (before === Infinity) auditLog(req.session.user, 'VIEWED_CHAT', nameA + ' & ' + nameB);
  res.json({
    a: nameA,
    b: nameB,
    hasMore: all.length > page.length,
    messages: page.map(publicMsg)
  });
});

app.get('/api/people', requireAdmin, (req, res) => {
  res.json(readJSON(PEOPLE_FILE, []));
});

app.post('/api/people', requireAdmin, (req, res) => {
  const { name, email } = req.body;
  if (typeof name !== 'string' || typeof email !== 'string' ||
      !name.trim() || name.length > 100 || email.length > 200 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'A valid name and email are required' });
  }
  const people = readJSON(PEOPLE_FILE, []);
  const person = { id: crypto.randomUUID(), name: name.trim(), email: email.trim() };
  people.push(person);
  writeJSON(PEOPLE_FILE, people);
  res.json(person);
});

app.delete('/api/people/:id', requireAdmin, (req, res) => {
  writeJSON(PEOPLE_FILE, readJSON(PEOPLE_FILE, []).filter(p => String(p.id) !== req.params.id));
  res.json({ ok: true });
});

// ---------- Errors ----------
app.use((req, res) => {
  if (req.originalUrl.startsWith('/api')) return res.status(404).json({ error: 'Not found' });
  res.status(404).type('text').send('Not found');
});

app.use((err, req, res, next) => {
  const pic = /\/profile\/(avatar|banner)$/.exec(req.path);
  if (err.type === 'entity.too.large' && (pic || /\/file$/.test(req.path))) {
    const mb = pic ? (pic[1] === 'avatar' ? AVATAR_MB : BANNER_MB) : MAX_FILE_MB;
    return res.status(413).json({ error: 'File is too big (max ' + mb + ' MB)' });
  }
  if (err.type === 'entity.parse.failed' || err.type === 'entity.too.large') {
    return res.status(400).json({ error: 'Bad request' });
  }
  console.error(err);
  res.status(500).json({ error: 'Server error' });
});

app.listen(PORT, HOST, () => {
  console.log(`Server running at http://${HOST === '127.0.0.1' ? 'localhost' : HOST}:${PORT}`);
});
