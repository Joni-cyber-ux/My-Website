// Shared look for profiles (pictures, nicknames, banners, admin styling). Loaded by every page.
(function () {
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function hueOf(name) {
    var h = 0;
    for (var i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 360;
    return h;
  }

  function displayName(p) { return (p && (p.nickname || p.username)) || '?'; }
  function isAdmin(p) { return !!p && p.role === 'admin'; }

  // Round picture: their profile picture, or a coloured circle with their first letter
  function avatar(p, cls) {
    p = p || {};
    var name = displayName(p);
    var a = el('div', cls + (isAdmin(p) ? ' is-admin-av' : ''));
    a.style.setProperty('--hue', hueOf(p.username || name));
    if (p.avatar) {
      a.classList.add('has-img');
      var img = document.createElement('img');
      img.src = '/media/' + encodeURIComponent(p.avatar);
      img.alt = '';
      img.draggable = false;
      a.appendChild(img);
    } else {
      a.textContent = (Array.from(name)[0] || '?').toUpperCase();
      if (p.color) a.style.background = p.color;
    }
    return a;
  }

  // The name as text. Admins get the gold name.
  function nameEl(p, cls) {
    return el('span', (cls ? cls + ' ' : '') + (isAdmin(p) ? 'admin-name' : ''), displayName(p));
  }

  function badge() { return el('span', 'pill admin', 'Admin'); }

  // The full profile card (banner, picture, names, about me)
  function card(p, opts) {
    opts = opts || {};
    p = p || {};
    var c = el('div', 'pcard');

    var banner = el('div', 'pbanner');
    if (p.color) banner.style.background = p.color;
    if (p.banner) {
      var bi = document.createElement('img');
      bi.src = '/media/' + encodeURIComponent(p.banner);
      bi.alt = '';
      bi.draggable = false;
      banner.appendChild(bi);
    }
    c.appendChild(banner);

    var body = el('div', 'pbody');
    var pav = el('div', 'pav');
    pav.appendChild(avatar(p, 'avatar-xl'));
    if (opts.online) pav.appendChild(el('span', 'online-dot'));
    body.appendChild(pav);

    var names = el('div', 'pnames');
    names.appendChild(nameEl(p, 'pname'));
    if (isAdmin(p)) names.appendChild(badge());
    body.appendChild(names);
    body.appendChild(el('div', 'puser', '@' + (p.username || '')));

    if (p.bio) body.appendChild(el('div', 'pbio', p.bio));

    if (p.since) {
      var d = new Date(p.since);
      if (!isNaN(d.getTime())) {
        body.appendChild(el('div', 'pmeta', 'Member since ' + d.toLocaleDateString([], { month: 'long', year: 'numeric' })));
      }
    }

    if (opts.editHref) {
      var edit = el('a', 'btn secondary small pedit', 'Edit profile');
      edit.href = opts.editHref;
      body.appendChild(edit);
    }

    c.appendChild(body);
    return c;
  }

  window.ProfileUI = { displayName: displayName, isAdmin: isAdmin, avatar: avatar, nameEl: nameEl, badge: badge, card: card };
})();
