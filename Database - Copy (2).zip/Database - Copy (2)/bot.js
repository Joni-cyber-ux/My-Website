'use strict';
// The Discord bot. It runs inside the same process as the website (started from server.js).

const {
  Client,
  Events,
  GatewayIntentBits,
  ApplicationCommandOptionType,
  MessageFlags,
  PermissionsBitField
} = require('discord.js');

const TOKEN = process.env.DISCORD_TOKEN;
const GUILD_ID = process.env.GUILD_ID;
const enabled = Boolean(TOKEN && GUILD_ID);

let client = null;
let ready = false;

// Errors with a message that is safe to show to the website user
class UserError extends Error {}

const PERMISSION_LABELS = [
  ['ManageGuild', 'Manage the server'],
  ['ManageRoles', 'Manage roles'],
  ['ManageChannels', 'Manage channels'],
  ['KickMembers', 'Kick members'],
  ['BanMembers', 'Ban members'],
  ['ModerateMembers', 'Timeout members'],
  ['ManageNicknames', 'Change other people\u2019s nicknames'],
  ['ManageMessages', 'Delete other people\u2019s messages'],
  ['MentionEveryone', 'Mention @everyone'],
  ['ViewAuditLog', 'View the audit log'],
  ['ChangeNickname', 'Change your own nickname']
];

function start({ handleLink }) {
  if (!enabled) {
    console.log('Discord bot: not configured (add DISCORD_TOKEN and GUILD_ID to .env to turn it on).');
    return;
  }

  client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

  client.once(Events.ClientReady, async () => {
    try {
      const guild = await client.guilds.fetch(GUILD_ID);
      await guild.members.fetch(); // load members so roles/nicknames are available
      await guild.commands.set([{
        name: 'link',
        description: 'Link your Discord account to the website',
        options: [{
          type: ApplicationCommandOptionType.String,
          name: 'code',
          description: 'The code shown on the website',
          required: true
        }]
      }]);
      ready = true;
      console.log(`Discord bot online as ${client.user.tag} in "${guild.name}".`);
    } catch (err) {
      console.error('Discord bot: could not set up. Is the bot in your server and is GUILD_ID correct?', err.message);
    }
  });

  client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.guildId !== GUILD_ID) return;
    if (interaction.commandName !== 'link') return;

    const code = interaction.options.getString('code').trim().toUpperCase();
    const result = handleLink(code, { id: interaction.user.id });
    await interaction.reply({ content: result.message, flags: MessageFlags.Ephemeral }).catch(() => {});
  });

  client.on('error', err => console.error('Discord client error:', err.message));
  client.login(TOKEN).catch(err => console.error('Discord login failed (check DISCORD_TOKEN):', err.message));
}

async function getGuild() {
  if (!ready) throw new UserError('The Discord bot is not online right now.');
  return client.guilds.cache.get(GUILD_ID) || client.guilds.fetch(GUILD_ID);
}

// Everything the website shows about one Discord account
async function getMemberInfo(discordId) {
  const guild = await getGuild();

  let member = null;
  try { member = await guild.members.fetch(discordId); }
  catch (err) { if (err.code !== 10007) throw err; } // 10007 = not in the server

  let ban = null;
  try { ban = await guild.bans.fetch(discordId); }
  catch (err) { if (err.code !== 10026) throw err; } // 10026 = not banned

  const user = member ? member.user : (ban ? ban.user : await client.users.fetch(discordId));

  const info = {
    id: user.id,
    username: user.username,
    avatar: user.displayAvatarURL({ extension: 'png', size: 128 }),
    accountCreated: user.createdAt.toISOString(),
    inServer: Boolean(member),
    isOwner: guild.ownerId === user.id,
    banned: Boolean(ban),
    banReason: ban ? (ban.reason || null) : null,
    nickname: null,
    displayName: user.globalName || user.username,
    joinedAt: null,
    timeoutUntil: null,
    roles: [],
    permissions: [],
    canBotManage: false
  };

  if (member) {
    info.nickname = member.nickname;
    info.displayName = member.displayName;
    info.joinedAt = member.joinedAt ? member.joinedAt.toISOString() : null;
    info.canBotManage = member.manageable;

    const until = member.communicationDisabledUntil;
    if (until && until.getTime() > Date.now()) info.timeoutUntil = until.toISOString();

    info.roles = member.roles.cache
      .filter(r => r.id !== guild.id) // skip @everyone
      .sort((a, b) => b.position - a.position)
      .map(r => ({ id: r.id, name: r.name, color: r.color ? r.hexColor : null }));

    if (member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      info.permissions = ['Administrator (can do everything)'];
    } else {
      info.permissions = PERMISSION_LABELS
        .filter(([flag]) => member.permissions.has(PermissionsBitField.Flags[flag]))
        .map(([, label]) => label);
    }
  }

  return info;
}

async function setNickname(discordId, nickname, reason) {
  const guild = await getGuild();
  let member;
  try { member = await guild.members.fetch(discordId); }
  catch (err) {
    if (err.code === 10007) throw new UserError('You are not in the Discord server.');
    throw err;
  }
  if (!member.manageable) {
    throw new UserError('I can\u2019t change that nickname. The person is the server owner or has a higher role than my bot.');
  }
  await member.setNickname(nickname || null, reason);
}

module.exports = {
  enabled,
  start,
  isReady: () => ready,
  getMemberInfo,
  setNickname,
  UserError
};
