1. Stop the server (Ctrl+C) and put all these files in your Database folder (replace the old ones).
2. Start:      node server.js
3. Open:       http://localhost:3000
(First time only: node setup.js creates the admin account.)

Admin-only tools on the Admin page:
- Click "Code" next to a user to get a one-time login code for their account.
- "Every conversation" lists every chat on the site; click one to read it (read-only).
Every code and every conversation view is written to admin-audit.log in this folder.

Change password (new):
- Every logged-in user and the admin has a "Change password" button (bottom of the chat sidebar, and in the Admin page header).
- It asks for the current password, then the new one twice. Other devices are logged out; this one stays logged in.
- Only 5 wrong "current password" tries are allowed per 15 minutes. Changes are written to login-log.txt.
- This update only replaces: server.js, chat.html, index.html, style.css, README.txt and adds password.html.
  Your users.json, .env and messages are NOT included, so nothing of yours gets overwritten.

Sending files and pictures (new):
- In a chat, click the paperclip next to the message box, paste a picture into it, or drag a file onto the chat. Max 25 MB per file
  (change it by adding  MAX_FILE_MB=50  to your .env file; the limit is 100).
- Pictures (png, jpg, gif, webp) show inside the chat. Everything else shows as a file you click to download.
- Files are saved in the new "uploads" folder (random names). Deleting a message deletes its file too.
- Only the two people in the chat can open a file. Admins can open files in "Every conversation" (written to admin-audit.log like chat views).
- This update replaces: server.js, chat.html, index.html, adminchat.html, style.css, README.txt, .gitignore.

Profiles (new):
- Everyone has "Edit profile" (bottom of the chat sidebar, and in the Admin page header). They can set a nickname, a profile picture,
  a banner picture, a colour and an "About me". Pictures are png, jpg, gif or webp (animated gifs work). Profile picture max 2 MB, banner max 5 MB.
  Big photos from a phone are shrunk automatically.
- Click someone's picture or name at the top of a chat to see their profile card.
- Nicknames can't be the same as another account's username, and @username is always shown on the profile card.
- Admins get a gold name, a gold ring around their picture and an "Admin" badge everywhere.
- Pictures are saved in the new "profile-pics" folder. Keep it when you move or back up the site.

Admin passwords (changed):
- Admins can no longer change their password from the website (the button and page are gone, the server refuses it too).
- To change the admin password yourself, run  node setup.js  again on the server.
